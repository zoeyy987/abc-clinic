import { useState } from 'react';
import { BarChart3, FileText, LogOut, Users, DollarSign, Calendar, TrendingUp } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';

interface AdminPortalProps {
  onLogout: () => void;
}

export function AdminPortal({ onLogout }: AdminPortalProps) {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'doctors' | 'reports'>('dashboard');

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <h1 className="text-2xl text-[#0F172A]">Admin Portal</h1>
            <nav className="flex gap-6 items-center">
              <button 
                onClick={() => setActiveTab('dashboard')}
                className={`${activeTab === 'dashboard' ? 'text-[#0EA5A4]' : 'text-gray-600'}`}
              >
                Dashboard
              </button>
              <button 
                onClick={() => setActiveTab('doctors')}
                className={`${activeTab === 'doctors' ? 'text-[#0EA5A4]' : 'text-gray-600'}`}
              >
                Doctors
              </button>
              <button 
                onClick={() => setActiveTab('reports')}
                className={`${activeTab === 'reports' ? 'text-[#0EA5A4]' : 'text-gray-600'}`}
              >
                Reports
              </button>
              <Button 
                onClick={onLogout}
                variant="outline"
                className="flex items-center gap-2"
              >
                <LogOut className="w-4 h-4" />
                Logout
              </Button>
            </nav>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        {/* Dashboard View */}
        {activeTab === 'dashboard' && (
          <div>
            <h2 className="text-2xl mb-6 text-[#0F172A]">Dashboard Overview</h2>
            
            {/* Stats Grid */}
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              <Card className="p-6 shadow-sm">
                <div className="flex items-center justify-between mb-2">
                  <Users className="w-8 h-8 text-[#0EA5A4]" />
                </div>
                <p className="text-gray-600 text-sm">Total Patients</p>
                <p className="text-3xl text-[#0F172A]">1,247</p>
              </Card>

              <Card className="p-6 shadow-sm">
                <div className="flex items-center justify-between mb-2">
                  <Calendar className="w-8 h-8 text-[#0EA5A4]" />
                </div>
                <p className="text-gray-600 text-sm">Total Appointments</p>
                <p className="text-3xl text-[#0F172A]">3,856</p>
              </Card>

              <Card className="p-6 shadow-sm">
                <div className="flex items-center justify-between mb-2">
                  <DollarSign className="w-8 h-8 text-[#0EA5A4]" />
                </div>
                <p className="text-gray-600 text-sm">Revenue Summary</p>
                <p className="text-3xl text-[#0F172A]">₱2.4M</p>
              </Card>

              <Card className="p-6 shadow-sm">
                <div className="flex items-center justify-between mb-2">
                  <TrendingUp className="w-8 h-8 text-[#0EA5A4]" />
                </div>
                <p className="text-gray-600 text-sm">Growth Rate</p>
                <p className="text-3xl text-[#0F172A]">+12%</p>
              </Card>
            </div>

            {/* Clinic Comparison */}
            <Card className="p-6 shadow-sm">
              <h3 className="text-xl mb-4 text-[#0F172A]">Clinic Comparison</h3>
              <div className="grid md:grid-cols-2 gap-6">
                <div className="border-l-4 border-[#0EA5A4] pl-4">
                  <p className="text-lg mb-2 text-[#0F172A]">Manila</p>
                  <div className="space-y-2 text-gray-700">
                    <p>Patients: 782</p>
                    <p>Appointments: 2,341</p>
                    <p>Revenue: ₱1.5M</p>
                  </div>
                </div>
                <div className="border-l-4 border-gray-300 pl-4">
                  <p className="text-lg mb-2 text-[#0F172A]">Cagayan de Oro</p>
                  <div className="space-y-2 text-gray-700">
                    <p>Patients: 465</p>
                    <p>Appointments: 1,515</p>
                    <p>Revenue: ₱900K</p>
                  </div>
                </div>
              </div>
            </Card>
          </div>
        )}

        {/* Doctors View */}
        {activeTab === 'doctors' && (
          <div>
            <h2 className="text-2xl mb-6 text-[#0F172A]">Doctors Management</h2>
            
            <Card className="shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-gray-700">Doctor Name</th>
                      <th className="px-6 py-3 text-left text-gray-700">Specialty</th>
                      <th className="px-6 py-3 text-left text-gray-700">Clinic</th>
                      <th className="px-6 py-3 text-left text-gray-700">Patients</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    <tr>
                      <td className="px-6 py-4 text-gray-900">Dr. Maria Santos</td>
                      <td className="px-6 py-4 text-gray-600">General Medicine</td>
                      <td className="px-6 py-4 text-gray-600">Manila</td>
                      <td className="px-6 py-4 text-gray-600">324</td>
                    </tr>
                    <tr>
                      <td className="px-6 py-4 text-gray-900">Dr. Jose Reyes</td>
                      <td className="px-6 py-4 text-gray-600">Pediatrics</td>
                      <td className="px-6 py-4 text-gray-600">Manila</td>
                      <td className="px-6 py-4 text-gray-600">458</td>
                    </tr>
                    <tr>
                      <td className="px-6 py-4 text-gray-900">Dr. Ana Cruz</td>
                      <td className="px-6 py-4 text-gray-600">Internal Medicine</td>
                      <td className="px-6 py-4 text-gray-600">Cagayan de Oro</td>
                      <td className="px-6 py-4 text-gray-600">287</td>
                    </tr>
                    <tr>
                      <td className="px-6 py-4 text-gray-900">Dr. Carlos Mendez</td>
                      <td className="px-6 py-4 text-gray-600">General Medicine</td>
                      <td className="px-6 py-4 text-gray-600">Cagayan de Oro</td>
                      <td className="px-6 py-4 text-gray-600">178</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </Card>
          </div>
        )}

        {/* Reports View */}
        {activeTab === 'reports' && (
          <div>
            <h2 className="text-2xl mb-6 text-[#0F172A]">Reports</h2>
            
            <div className="mb-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <p className="text-gray-700">
                <strong>Note:</strong> Data pre-aggregated using DynamoDB design for fast retrieval.
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              <Card className="p-6 shadow-sm">
                <div className="flex items-center gap-3 mb-4">
                  <BarChart3 className="w-8 h-8 text-[#0EA5A4]" />
                  <h3 className="text-xl text-[#0F172A]">Quarterly Revenue Report</h3>
                </div>
                <p className="text-gray-600 mb-4">Q1 2025 financial summary across all clinics</p>
                <Button className="bg-[#0EA5A4] hover:bg-[#0d8f8e] text-white">
                  Generate Report
                </Button>
              </Card>

              <Card className="p-6 shadow-sm">
                <div className="flex items-center gap-3 mb-4">
                  <Users className="w-8 h-8 text-[#0EA5A4]" />
                  <h3 className="text-xl text-[#0F172A]">Doctor Revenue Breakdown</h3>
                </div>
                <p className="text-gray-600 mb-4">Individual doctor performance metrics</p>
                <Button className="bg-[#0EA5A4] hover:bg-[#0d8f8e] text-white">
                  Generate Report
                </Button>
              </Card>

              <Card className="p-6 shadow-sm">
                <div className="flex items-center gap-3 mb-4">
                  <Calendar className="w-8 h-8 text-[#0EA5A4]" />
                  <h3 className="text-xl text-[#0F172A]">Appointment Summary</h3>
                </div>
                <p className="text-gray-600 mb-4">Monthly appointment trends and patterns</p>
                <Button className="bg-[#0EA5A4] hover:bg-[#0d8f8e] text-white">
                  Generate Report
                </Button>
              </Card>

              <Card className="p-6 shadow-sm">
                <div className="flex items-center gap-3 mb-4">
                  <FileText className="w-8 h-8 text-[#0EA5A4]" />
                  <h3 className="text-xl text-[#0F172A]">Patient Statistics</h3>
                </div>
                <p className="text-gray-600 mb-4">Demographics and visit frequency analysis</p>
                <Button className="bg-[#0EA5A4] hover:bg-[#0d8f8e] text-white">
                  Generate Report
                </Button>
              </Card>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
