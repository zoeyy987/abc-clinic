
  # Minimal Three-Portal Website

  This is a code bundle for Minimal Three-Portal Website. The original project is available at https://www.figma.com/design/7LZKedZJgw2V0lzDcK7HHE/Minimal-Three-Portal-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  