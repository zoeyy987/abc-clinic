import { Building2, Calendar, FileText, Hospital, MapPin, Stethoscope, Users } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';

interface LandingPageProps {
  onNavigate: (page: 'admin' | 'doctor' | 'secretary') => void;
}

export function LandingPage({ onNavigate }: LandingPageProps) {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-b from-gray-50 to-white py-20 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-5xl mb-4 text-[#0F172A]">ABC Clinics</h1>
          <p className="text-xl text-gray-600 mb-2">Manila & Cagayan de Oro</p>
          <p className="text-lg text-gray-700 mb-8 max-w-2xl mx-auto">
            Patient-first care with simple scheduling and organized records.
          </p>
          
          <div className="flex gap-4 justify-center flex-wrap">
            <Button 
              onClick={() => onNavigate('admin')}
              className="bg-[#0EA5A4] hover:bg-[#0d8f8e] text-white px-8 py-6 rounded-lg shadow-md"
            >
              Admin Login
            </Button>
            <Button 
              onClick={() => onNavigate('doctor')}
              className="bg-[#0EA5A4] hover:bg-[#0d8f8e] text-white px-8 py-6 rounded-lg shadow-md"
            >
              Doctor Login
            </Button>
            <Button 
              onClick={() => onNavigate('secretary')}
              className="bg-[#0EA5A4] hover:bg-[#0d8f8e] text-white px-8 py-6 rounded-lg shadow-md"
            >
              Secretary Login
            </Button>
          </div>
        </div>
      </section>

      {/* Clinics Section */}
      <section className="py-16 px-4 bg-white">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-3xl text-center mb-12 text-[#0F172A]">Our Clinics</h2>
          <div className="grid md:grid-cols-2 gap-8">
            <Card className="p-8 text-center shadow-sm">
              <MapPin className="w-12 h-12 mx-auto mb-4 text-[#0EA5A4]" />
              <h3 className="text-2xl mb-2 text-[#0F172A]">Manila</h3>
              <p className="text-gray-600">Main clinic location</p>
            </Card>
            <Card className="p-8 text-center shadow-sm">
              <MapPin className="w-12 h-12 mx-auto mb-4 text-[#0EA5A4]" />
              <h3 className="text-2xl mb-2 text-[#0F172A]">Cagayan de Oro</h3>
              <p className="text-gray-600">Branch clinic location</p>
            </Card>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-16 px-4 bg-gray-50">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-3xl text-center mb-12 text-[#0F172A]">Services</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <Calendar className="w-12 h-12 mx-auto mb-4 text-[#0EA5A4]" />
              <h3 className="text-xl mb-2 text-[#0F172A]">Appointment Scheduling</h3>
              <p className="text-gray-600">Easy booking system</p>
            </div>
            <div className="text-center">
              <Stethoscope className="w-12 h-12 mx-auto mb-4 text-[#0EA5A4]" />
              <h3 className="text-xl mb-2 text-[#0F172A]">Consultations</h3>
              <p className="text-gray-600">Expert medical care</p>
            </div>
            <div className="text-center">
              <FileText className="w-12 h-12 mx-auto mb-4 text-[#0EA5A4]" />
              <h3 className="text-xl mb-2 text-[#0F172A]">Medical Records</h3>
              <p className="text-gray-600">Organized documentation</p>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-16 px-4 bg-white">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-3xl text-center mb-12 text-[#0F172A]">How It Works</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="p-6 shadow-sm">
              <div className="w-10 h-10 rounded-full bg-[#0EA5A4] text-white flex items-center justify-center mb-4">1</div>
              <h3 className="text-xl mb-2 text-[#0F172A]">Book Appointment</h3>
              <p className="text-gray-600">Schedule your visit with our secretary</p>
            </Card>
            <Card className="p-6 shadow-sm">
              <div className="w-10 h-10 rounded-full bg-[#0EA5A4] text-white flex items-center justify-center mb-4">2</div>
              <h3 className="text-xl mb-2 text-[#0F172A]">Consultation</h3>
              <p className="text-gray-600">Meet with our qualified doctors</p>
            </Card>
            <Card className="p-6 shadow-sm">
              <div className="w-10 h-10 rounded-full bg-[#0EA5A4] text-white flex items-center justify-center mb-4">3</div>
              <h3 className="text-xl mb-2 text-[#0F172A]">Diagnosis & Prescription</h3>
              <p className="text-gray-600">Receive your treatment plan</p>
            </Card>
          </div>
        </div>
      </section>

      {/* About the System Section */}
      <section className="py-16 px-4 bg-gray-50">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl text-center mb-8 text-[#0F172A]">About Our System</h2>
          <Card className="p-8 shadow-sm">
            <div className="mb-6">
              <h3 className="text-xl mb-3 text-[#0F172A]">The Challenge</h3>
              <p className="text-gray-700">
                Our previous system was slow and inconsistent, affecting patient care and administrative efficiency.
              </p>
            </div>
            <div>
              <h3 className="text-xl mb-3 text-[#0F172A]">Our Solution</h3>
              <p className="text-gray-700">
                A scalable DynamoDB-based model designed for fast lookups and comprehensive reporting across both clinic locations.
              </p>
            </div>
            <div className="mt-6 flex gap-4 flex-wrap justify-center">
              <div className="flex items-center gap-2 text-gray-700">
                <Users className="w-5 h-5 text-[#0EA5A4]" />
                <span>Administrator, Doctor, Secretary roles</span>
              </div>
              <div className="flex items-center gap-2 text-gray-700">
                <Hospital className="w-5 h-5 text-[#0EA5A4]" />
                <span>Multi-clinic support</span>
              </div>
              <div className="flex items-center gap-2 text-gray-700">
                <Building2 className="w-5 h-5 text-[#0EA5A4]" />
                <span>Fast & scalable</span>
              </div>
            </div>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#0F172A] text-white py-8 px-4">
        <div className="max-w-5xl mx-auto text-center">
          <p className="mb-2">ABC Clinics - Manila & Cagayan de Oro</p>
          <p className="text-gray-400 text-sm">© 2025 ABC Clinics. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
