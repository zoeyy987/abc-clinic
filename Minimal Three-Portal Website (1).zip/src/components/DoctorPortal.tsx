import { useState } from 'react';
import { Calendar, FileText, LogOut, Users, Clock, Activity } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';

interface DoctorPortalProps {
  onLogout: () => void;
}

export function DoctorPortal({ onLogout }: DoctorPortalProps) {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'patients' | 'appointments' | 'records'>('dashboard');

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <h1 className="text-2xl text-[#0F172A]">Doctor Portal</h1>
            <nav className="flex gap-6 items-center">
              <button 
                onClick={() => setActiveTab('dashboard')}
                className={`${activeTab === 'dashboard' ? 'text-[#0EA5A4]' : 'text-gray-600'}`}
              >
                Dashboard
              </button>
              <button 
                onClick={() => setActiveTab('patients')}
                className={`${activeTab === 'patients' ? 'text-[#0EA5A4]' : 'text-gray-600'}`}
              >
                My Patients
              </button>
              <button 
                onClick={() => setActiveTab('appointments')}
                className={`${activeTab === 'appointments' ? 'text-[#0EA5A4]' : 'text-gray-600'}`}
              >
                Appointments
              </button>
              <button 
                onClick={() => setActiveTab('records')}
                className={`${activeTab === 'records' ? 'text-[#0EA5A4]' : 'text-gray-600'}`}
              >
                Records
              </button>
              <Button 
                onClick={onLogout}
                variant="outline"
                className="flex items-center gap-2"
              >
                <LogOut className="w-4 h-4" />
                Logout
              </Button>
            </nav>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        {/* Dashboard View */}
        {activeTab === 'dashboard' && (
          <div>
            <h2 className="text-2xl mb-6 text-[#0F172A]">Dashboard</h2>
            
            {/* Stats Grid */}
            <div className="grid md:grid-cols-3 gap-6 mb-8">
              <Card className="p-6 shadow-sm">
                <div className="flex items-center justify-between mb-2">
                  <Clock className="w-8 h-8 text-[#0EA5A4]" />
                </div>
                <p className="text-gray-600 text-sm">Today's Appointments</p>
                <p className="text-3xl text-[#0F172A]">8</p>
              </Card>

              <Card className="p-6 shadow-sm">
                <div className="flex items-center justify-between mb-2">
                  <Activity className="w-8 h-8 text-[#0EA5A4]" />
                </div>
                <p className="text-gray-600 text-sm">Pending Diagnoses</p>
                <p className="text-3xl text-[#0F172A]">3</p>
              </Card>

              <Card className="p-6 shadow-sm">
                <div className="flex items-center justify-between mb-2">
                  <Users className="w-8 h-8 text-[#0EA5A4]" />
                </div>
                <p className="text-gray-600 text-sm">Recent Patients</p>
                <p className="text-3xl text-[#0F172A]">24</p>
              </Card>
            </div>

            {/* Today's Schedule */}
            <Card className="p-6 shadow-sm">
              <h3 className="text-xl mb-4 text-[#0F172A]">Today's Schedule</h3>
              <div className="space-y-3">
                <div className="flex items-center justify-between p-3 bg-gray-50 rounded">
                  <div>
                    <p className="text-[#0F172A]">Maria dela Cruz</p>
                    <p className="text-sm text-gray-600">General Checkup</p>
                  </div>
                  <p className="text-gray-700">9:00 AM</p>
                </div>
                <div className="flex items-center justify-between p-3 bg-gray-50 rounded">
                  <div>
                    <p className="text-[#0F172A]">Juan Santos</p>
                    <p className="text-sm text-gray-600">Follow-up</p>
                  </div>
                  <p className="text-gray-700">10:30 AM</p>
                </div>
                <div className="flex items-center justify-between p-3 bg-gray-50 rounded">
                  <div>
                    <p className="text-[#0F172A]">Ana Rodriguez</p>
                    <p className="text-sm text-gray-600">Consultation</p>
                  </div>
                  <p className="text-gray-700">2:00 PM</p>
                </div>
              </div>
            </Card>
          </div>
        )}

        {/* Patients View */}
        {activeTab === 'patients' && (
          <div>
            <h2 className="text-2xl mb-6 text-[#0F172A]">My Patients</h2>
            
            <Card className="shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-gray-700">Patient Name</th>
                      <th className="px-6 py-3 text-left text-gray-700">Age</th>
                      <th className="px-6 py-3 text-left text-gray-700">Last Visit</th>
                      <th className="px-6 py-3 text-left text-gray-700">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    <tr>
                      <td className="px-6 py-4 text-gray-900">Maria dela Cruz</td>
                      <td className="px-6 py-4 text-gray-600">45</td>
                      <td className="px-6 py-4 text-gray-600">Nov 18, 2025</td>
                      <td className="px-6 py-4">
                        <Button size="sm" className="bg-[#0EA5A4] hover:bg-[#0d8f8e] text-white">
                          View History
                        </Button>
                      </td>
                    </tr>
                    <tr>
                      <td className="px-6 py-4 text-gray-900">Juan Santos</td>
                      <td className="px-6 py-4 text-gray-600">32</td>
                      <td className="px-6 py-4 text-gray-600">Nov 15, 2025</td>
                      <td className="px-6 py-4">
                        <Button size="sm" className="bg-[#0EA5A4] hover:bg-[#0d8f8e] text-white">
                          View History
                        </Button>
                      </td>
                    </tr>
                    <tr>
                      <td className="px-6 py-4 text-gray-900">Ana Rodriguez</td>
                      <td className="px-6 py-4 text-gray-600">28</td>
                      <td className="px-6 py-4 text-gray-600">Nov 12, 2025</td>
                      <td className="px-6 py-4">
                        <Button size="sm" className="bg-[#0EA5A4] hover:bg-[#0d8f8e] text-white">
                          View History
                        </Button>
                      </td>
                    </tr>
                    <tr>
                      <td className="px-6 py-4 text-gray-900">Pedro Gonzales</td>
                      <td className="px-6 py-4 text-gray-600">56</td>
                      <td className="px-6 py-4 text-gray-600">Nov 10, 2025</td>
                      <td className="px-6 py-4">
                        <Button size="sm" className="bg-[#0EA5A4] hover:bg-[#0d8f8e] text-white">
                          View History
                        </Button>
                      </td>
                    </tr>
                    <tr>
                      <td className="px-6 py-4 text-gray-900">Elena Flores</td>
                      <td className="px-6 py-4 text-gray-600">41</td>
                      <td className="px-6 py-4 text-gray-600">Nov 8, 2025</td>
                      <td className="px-6 py-4">
                        <Button size="sm" className="bg-[#0EA5A4] hover:bg-[#0d8f8e] text-white">
                          View History
                        </Button>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </Card>
          </div>
        )}

        {/* Appointments View */}
        {activeTab === 'appointments' && (
          <div>
            <h2 className="text-2xl mb-6 text-[#0F172A]">Appointments</h2>
            
            <Card className="p-6 shadow-sm">
              <h3 className="text-xl mb-4 text-[#0F172A]">Today's Schedule - November 19, 2025</h3>
              <div className="space-y-4">
                <div className="border-l-4 border-[#0EA5A4] pl-4 py-2">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="text-lg text-[#0F172A]">Maria dela Cruz</p>
                      <p className="text-gray-600">General Checkup</p>
                      <p className="text-sm text-gray-500">Contact: 0912-345-6789</p>
                    </div>
                    <p className="text-[#0F172A]">9:00 AM</p>
                  </div>
                </div>

                <div className="border-l-4 border-[#0EA5A4] pl-4 py-2">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="text-lg text-[#0F172A]">Juan Santos</p>
                      <p className="text-gray-600">Follow-up Consultation</p>
                      <p className="text-sm text-gray-500">Contact: 0923-456-7890</p>
                    </div>
                    <p className="text-[#0F172A]">10:30 AM</p>
                  </div>
                </div>

                <div className="border-l-4 border-gray-300 pl-4 py-2">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="text-lg text-[#0F172A]">Ana Rodriguez</p>
                      <p className="text-gray-600">New Patient Consultation</p>
                      <p className="text-sm text-gray-500">Contact: 0934-567-8901</p>
                    </div>
                    <p className="text-[#0F172A]">2:00 PM</p>
                  </div>
                </div>

                <div className="border-l-4 border-gray-300 pl-4 py-2">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="text-lg text-[#0F172A]">Pedro Gonzales</p>
                      <p className="text-gray-600">Lab Results Review</p>
                      <p className="text-sm text-gray-500">Contact: 0945-678-9012</p>
                    </div>
                    <p className="text-[#0F172A]">3:30 PM</p>
                  </div>
                </div>
              </div>
            </Card>
          </div>
        )}

        {/* Records View */}
        {activeTab === 'records' && (
          <div>
            <h2 className="text-2xl mb-6 text-[#0F172A]">Patient Records</h2>
            
            <div className="mb-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <p className="text-gray-700">
                <strong>Note:</strong> Denormalized medical records for faster lookups.
              </p>
            </div>

            <Card className="p-6 shadow-sm">
              <h3 className="text-xl mb-4 text-[#0F172A]">Recent Patient Record</h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm text-gray-700 mb-1">Patient Name</label>
                  <input 
                    type="text" 
                    className="w-full px-3 py-2 border border-gray-300 rounded"
                    placeholder="Maria dela Cruz"
                    disabled
                  />
                </div>

                <div>
                  <label className="block text-sm text-gray-700 mb-1">Diagnosis</label>
                  <textarea 
                    className="w-full px-3 py-2 border border-gray-300 rounded"
                    rows={3}
                    placeholder="Enter diagnosis here..."
                  />
                </div>

                <div>
                  <label className="block text-sm text-gray-700 mb-1">Prescription</label>
                  <textarea 
                    className="w-full px-3 py-2 border border-gray-300 rounded"
                    rows={3}
                    placeholder="Enter prescription details..."
                  />
                </div>

                <div>
                  <label className="block text-sm text-gray-700 mb-1">Recommended Procedures</label>
                  <textarea 
                    className="w-full px-3 py-2 border border-gray-300 rounded"
                    rows={2}
                    placeholder="Enter recommended procedures..."
                  />
                </div>

                <div>
                  <label className="block text-sm text-gray-700 mb-1">Notes</label>
                  <textarea 
                    className="w-full px-3 py-2 border border-gray-300 rounded"
                    rows={2}
                    placeholder="Additional notes..."
                  />
                </div>

                <Button className="bg-[#0EA5A4] hover:bg-[#0d8f8e] text-white">
                  Save Record
                </Button>
              </div>
            </Card>
          </div>
        )}
      </main>
    </div>
  );
}
