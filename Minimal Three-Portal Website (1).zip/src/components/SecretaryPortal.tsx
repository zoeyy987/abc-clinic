import { useState } from 'react';
import { Calendar, DollarSign, LogOut, Users, Clock, CheckCircle } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';

interface SecretaryPortalProps {
  onLogout: () => void;
}

export function SecretaryPortal({ onLogout }: SecretaryPortalProps) {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'schedule' | 'payments' | 'patients'>('dashboard');

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <h1 className="text-2xl text-[#0F172A]">Secretary Portal</h1>
            <nav className="flex gap-6 items-center">
              <button 
                onClick={() => setActiveTab('dashboard')}
                className={`${activeTab === 'dashboard' ? 'text-[#0EA5A4]' : 'text-gray-600'}`}
              >
                Dashboard
              </button>
              <button 
                onClick={() => setActiveTab('schedule')}
                className={`${activeTab === 'schedule' ? 'text-[#0EA5A4]' : 'text-gray-600'}`}
              >
                Schedule Appointment
              </button>
              <button 
                onClick={() => setActiveTab('payments')}
                className={`${activeTab === 'payments' ? 'text-[#0EA5A4]' : 'text-gray-600'}`}
              >
                Payments
              </button>
              <button 
                onClick={() => setActiveTab('patients')}
                className={`${activeTab === 'patients' ? 'text-[#0EA5A4]' : 'text-gray-600'}`}
              >
                Patients
              </button>
              <Button 
                onClick={onLogout}
                variant="outline"
                className="flex items-center gap-2"
              >
                <LogOut className="w-4 h-4" />
                Logout
              </Button>
            </nav>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        {/* Dashboard View */}
        {activeTab === 'dashboard' && (
          <div>
            <h2 className="text-2xl mb-6 text-[#0F172A]">Dashboard</h2>
            
            {/* Stats Grid */}
            <div className="grid md:grid-cols-3 gap-6 mb-8">
              <Card className="p-6 shadow-sm">
                <div className="flex items-center justify-between mb-2">
                  <Calendar className="w-8 h-8 text-[#0EA5A4]" />
                </div>
                <p className="text-gray-600 text-sm">Upcoming Appointments</p>
                <p className="text-3xl text-[#0F172A]">12</p>
              </Card>

              <Card className="p-6 shadow-sm">
                <div className="flex items-center justify-between mb-2">
                  <Users className="w-8 h-8 text-[#0EA5A4]" />
                </div>
                <p className="text-gray-600 text-sm">New Patients (This Week)</p>
                <p className="text-3xl text-[#0F172A]">5</p>
              </Card>

              <Card className="p-6 shadow-sm">
                <div className="flex items-center justify-between mb-2">
                  <DollarSign className="w-8 h-8 text-[#0EA5A4]" />
                </div>
                <p className="text-gray-600 text-sm">Payments Collected Today</p>
                <p className="text-3xl text-[#0F172A]">₱8,500</p>
              </Card>
            </div>

            {/* Today's Appointments */}
            <Card className="p-6 shadow-sm">
              <h3 className="text-xl mb-4 text-[#0F172A]">Today's Appointments</h3>
              <div className="space-y-3">
                <div className="flex items-center justify-between p-3 bg-gray-50 rounded">
                  <div className="flex items-center gap-3">
                    <Clock className="w-5 h-5 text-[#0EA5A4]" />
                    <div>
                      <p className="text-[#0F172A]">9:00 AM - Maria dela Cruz</p>
                      <p className="text-sm text-gray-600">Dr. Santos</p>
                    </div>
                  </div>
                  <CheckCircle className="w-5 h-5 text-green-600" />
                </div>
                <div className="flex items-center justify-between p-3 bg-gray-50 rounded">
                  <div className="flex items-center gap-3">
                    <Clock className="w-5 h-5 text-[#0EA5A4]" />
                    <div>
                      <p className="text-[#0F172A]">10:30 AM - Juan Santos</p>
                      <p className="text-sm text-gray-600">Dr. Santos</p>
                    </div>
                  </div>
                  <CheckCircle className="w-5 h-5 text-green-600" />
                </div>
                <div className="flex items-center justify-between p-3 bg-gray-50 rounded">
                  <div className="flex items-center gap-3">
                    <Clock className="w-5 h-5 text-gray-400" />
                    <div>
                      <p className="text-[#0F172A]">2:00 PM - Ana Rodriguez</p>
                      <p className="text-sm text-gray-600">Dr. Santos</p>
                    </div>
                  </div>
                  <div className="w-5 h-5" />
                </div>
              </div>
            </Card>
          </div>
        )}

        {/* Schedule Appointment View */}
        {activeTab === 'schedule' && (
          <div>
            <h2 className="text-2xl mb-6 text-[#0F172A]">Schedule Appointment</h2>
            
            <Card className="p-6 shadow-sm max-w-2xl">
              <div className="space-y-4">
                <div>
                  <label className="block text-sm text-gray-700 mb-1">Patient Name</label>
                  <input 
                    type="text" 
                    className="w-full px-3 py-2 border border-gray-300 rounded"
                    placeholder="Enter patient name"
                  />
                </div>

                <div>
                  <label className="block text-sm text-gray-700 mb-1">Contact Number</label>
                  <input 
                    type="text" 
                    className="w-full px-3 py-2 border border-gray-300 rounded"
                    placeholder="0912-345-6789"
                  />
                </div>

                <div>
                  <label className="block text-sm text-gray-700 mb-1">Doctor</label>
                  <select className="w-full px-3 py-2 border border-gray-300 rounded">
                    <option>Select a doctor</option>
                    <option>Dr. Maria Santos - General Medicine</option>
                    <option>Dr. Jose Reyes - Pediatrics</option>
                    <option>Dr. Ana Cruz - Internal Medicine</option>
                    <option>Dr. Carlos Mendez - General Medicine</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm text-gray-700 mb-1">Clinic</label>
                  <select className="w-full px-3 py-2 border border-gray-300 rounded">
                    <option>Select a clinic</option>
                    <option>Manila</option>
                    <option>Cagayan de Oro</option>
                  </select>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm text-gray-700 mb-1">Date</label>
                    <input 
                      type="date" 
                      className="w-full px-3 py-2 border border-gray-300 rounded"
                    />
                  </div>
                  <div>
                    <label className="block text-sm text-gray-700 mb-1">Time</label>
                    <input 
                      type="time" 
                      className="w-full px-3 py-2 border border-gray-300 rounded"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm text-gray-700 mb-1">Reason for Visit</label>
                  <textarea 
                    className="w-full px-3 py-2 border border-gray-300 rounded"
                    rows={3}
                    placeholder="Brief description of the reason for appointment"
                  />
                </div>

                <Button className="bg-[#0EA5A4] hover:bg-[#0d8f8e] text-white w-full">
                  Save Appointment
                </Button>
              </div>
            </Card>
          </div>
        )}

        {/* Payments View */}
        {activeTab === 'payments' && (
          <div>
            <h2 className="text-2xl mb-6 text-[#0F172A]">Payment Collection</h2>
            
            <Card className="shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-gray-700">Patient Name</th>
                      <th className="px-6 py-3 text-left text-gray-700">Service</th>
                      <th className="px-6 py-3 text-left text-gray-700">Amount</th>
                      <th className="px-6 py-3 text-left text-gray-700">Status</th>
                      <th className="px-6 py-3 text-left text-gray-700">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    <tr>
                      <td className="px-6 py-4 text-gray-900">Maria dela Cruz</td>
                      <td className="px-6 py-4 text-gray-600">General Checkup</td>
                      <td className="px-6 py-4 text-gray-900">₱1,500</td>
                      <td className="px-6 py-4">
                        <span className="px-2 py-1 text-xs rounded bg-green-100 text-green-800">Paid</span>
                      </td>
                      <td className="px-6 py-4 text-gray-400">Completed</td>
                    </tr>
                    <tr>
                      <td className="px-6 py-4 text-gray-900">Juan Santos</td>
                      <td className="px-6 py-4 text-gray-600">Follow-up</td>
                      <td className="px-6 py-4 text-gray-900">₱1,000</td>
                      <td className="px-6 py-4">
                        <span className="px-2 py-1 text-xs rounded bg-yellow-100 text-yellow-800">Pending</span>
                      </td>
                      <td className="px-6 py-4">
                        <Button size="sm" className="bg-[#0EA5A4] hover:bg-[#0d8f8e] text-white">
                          Mark as Paid
                        </Button>
                      </td>
                    </tr>
                    <tr>
                      <td className="px-6 py-4 text-gray-900">Ana Rodriguez</td>
                      <td className="px-6 py-4 text-gray-600">Consultation</td>
                      <td className="px-6 py-4 text-gray-900">₱2,000</td>
                      <td className="px-6 py-4">
                        <span className="px-2 py-1 text-xs rounded bg-yellow-100 text-yellow-800">Pending</span>
                      </td>
                      <td className="px-6 py-4">
                        <Button size="sm" className="bg-[#0EA5A4] hover:bg-[#0d8f8e] text-white">
                          Mark as Paid
                        </Button>
                      </td>
                    </tr>
                    <tr>
                      <td className="px-6 py-4 text-gray-900">Pedro Gonzales</td>
                      <td className="px-6 py-4 text-gray-600">Lab Results Review</td>
                      <td className="px-6 py-4 text-gray-900">₱800</td>
                      <td className="px-6 py-4">
                        <span className="px-2 py-1 text-xs rounded bg-green-100 text-green-800">Paid</span>
                      </td>
                      <td className="px-6 py-4 text-gray-400">Completed</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </Card>
          </div>
        )}

        {/* Patients View */}
        {activeTab === 'patients' && (
          <div>
            <h2 className="text-2xl mb-6 text-[#0F172A]">Patient Records</h2>
            
            <Card className="shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-gray-700">Patient Name</th>
                      <th className="px-6 py-3 text-left text-gray-700">Contact</th>
                      <th className="px-6 py-3 text-left text-gray-700">Last Visit</th>
                      <th className="px-6 py-3 text-left text-gray-700">Clinic</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    <tr>
                      <td className="px-6 py-4 text-gray-900">Maria dela Cruz</td>
                      <td className="px-6 py-4 text-gray-600">0912-345-6789</td>
                      <td className="px-6 py-4 text-gray-600">Nov 19, 2025</td>
                      <td className="px-6 py-4 text-gray-600">Manila</td>
                    </tr>
                    <tr>
                      <td className="px-6 py-4 text-gray-900">Juan Santos</td>
                      <td className="px-6 py-4 text-gray-600">0923-456-7890</td>
                      <td className="px-6 py-4 text-gray-600">Nov 19, 2025</td>
                      <td className="px-6 py-4 text-gray-600">Manila</td>
                    </tr>
                    <tr>
                      <td className="px-6 py-4 text-gray-900">Ana Rodriguez</td>
                      <td className="px-6 py-4 text-gray-600">0934-567-8901</td>
                      <td className="px-6 py-4 text-gray-600">Nov 12, 2025</td>
                      <td className="px-6 py-4 text-gray-600">Cagayan de Oro</td>
                    </tr>
                    <tr>
                      <td className="px-6 py-4 text-gray-900">Pedro Gonzales</td>
                      <td className="px-6 py-4 text-gray-600">0945-678-9012</td>
                      <td className="px-6 py-4 text-gray-600">Nov 10, 2025</td>
                      <td className="px-6 py-4 text-gray-600">Manila</td>
                    </tr>
                    <tr>
                      <td className="px-6 py-4 text-gray-900">Elena Flores</td>
                      <td className="px-6 py-4 text-gray-600">0956-789-0123</td>
                      <td className="px-6 py-4 text-gray-600">Nov 8, 2025</td>
                      <td className="px-6 py-4 text-gray-600">Cagayan de Oro</td>
                    </tr>
                    <tr>
                      <td className="px-6 py-4 text-gray-900">Roberto Aquino</td>
                      <td className="px-6 py-4 text-gray-600">0967-890-1234</td>
                      <td className="px-6 py-4 text-gray-600">Nov 5, 2025</td>
                      <td className="px-6 py-4 text-gray-600">Manila</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </Card>
          </div>
        )}
      </main>
    </div>
  );
}
