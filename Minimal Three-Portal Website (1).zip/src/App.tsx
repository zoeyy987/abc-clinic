import { useState } from 'react';
import { LandingPage } from './components/LandingPage';
import { AdminPortal } from './components/AdminPortal';
import { DoctorPortal } from './components/DoctorPortal';
import { SecretaryPortal } from './components/SecretaryPortal';

export default function App() {
  const [currentPage, setCurrentPage] = useState<'landing' | 'admin' | 'doctor' | 'secretary'>('landing');

  return (
    <div className="min-h-screen bg-white">
      {currentPage === 'landing' && <LandingPage onNavigate={setCurrentPage} />}
      {currentPage === 'admin' && <AdminPortal onLogout={() => setCurrentPage('landing')} />}
      {currentPage === 'doctor' && <DoctorPortal onLogout={() => setCurrentPage('landing')} />}
      {currentPage === 'secretary' && <SecretaryPortal onLogout={() => setCurrentPage('landing')} />}
    </div>
  );
}
